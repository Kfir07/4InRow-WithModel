package com.example.homework9_4inarow;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public boolean playerSwitch;
    public Button chosen, restart;
    public int c;
    public int winningRow, winningColumn;
    public String winningWay;
    public String id;
    public CountDownTimer cdt;
    public int player=0;
    public boolean active = true;
    public int[][] gameBoard = new int[6][7];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BuildGameBoard();
        playerSwitch = true;
        restart = findViewById(R.id.restart);
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cdt.cancel();
                Restart();
            }
        });
    }
    public void onClick (View view) {
        if (active) {
            chosen = (Button) view;
            id = FindByIntId(view.getId());
            if (!IsRowFull(id)) {
                if (playerSwitch) {
                    player = 1;
                    Mark(playerSwitch);
                } else {
                    player = 2;
                    Mark(playerSwitch);
                }
                if (CheckIfWon()) {
                    MarkWinner(winningRow, winningColumn, winningWay);
                    Toast.makeText(MainActivity.this, "Player " + player + " Won", Toast.LENGTH_LONG).show();
                    active = false;
                    EndGame();
                } else if (IsBoardFull()) {
                    Toast.makeText(MainActivity.this, "Its A Tie!!", Toast.LENGTH_LONG).show();
                    active = false;
                    EndGame();
                } else {
                    if (playerSwitch)
                        playerSwitch = false;
                    else
                        playerSwitch = true;
                }
            } else {
                Toast.makeText(MainActivity.this, "Row is full. Please select a different row", Toast.LENGTH_LONG).show();
            }
        }
    }//On click listener to all buttons on the board
    public void MarkWinner(int row, int column, String winningWay){
        c = Color.GREEN;
        if (winningWay == "Horizontal"){
            MatchPlacementToButton(row,column).setBackgroundColor(c);
            MatchPlacementToButton(row+1,column).setBackgroundColor(c);
            MatchPlacementToButton(row+2,column).setBackgroundColor(c);
            MatchPlacementToButton(row+3,column).setBackgroundColor(c);
        }
        if (winningWay == "Vertical"){
            MatchPlacementToButton(row,column).setBackgroundColor(c);
            MatchPlacementToButton(row,column+1).setBackgroundColor(c);
            MatchPlacementToButton(row,column+2).setBackgroundColor(c);
            MatchPlacementToButton(row,column+3).setBackgroundColor(c);
        }
        if (winningWay == "DiagonalRightDown"){
            MatchPlacementToButton(row,column).setBackgroundColor(c);
            MatchPlacementToButton(row+1,column+1).setBackgroundColor(c);
            MatchPlacementToButton(row+2,column+2).setBackgroundColor(c);
            MatchPlacementToButton(row+3,column+3).setBackgroundColor(c);
        }
        if (winningWay == "DiagonalRightUp"){
            MatchPlacementToButton(row,column).setBackgroundColor(c);
            MatchPlacementToButton(row+1,column-1).setBackgroundColor(c);
            MatchPlacementToButton(row+2,column-2).setBackgroundColor(c);
            MatchPlacementToButton(row+3,column-3).setBackgroundColor(c);
        }
        if (winningWay == "DiagonalLeftDown"){
            MatchPlacementToButton(row,column).setBackgroundColor(c);
            MatchPlacementToButton(row-1,column+1).setBackgroundColor(c);
            MatchPlacementToButton(row-2,column+2).setBackgroundColor(c);
            MatchPlacementToButton(row-3,column+3).setBackgroundColor(c);
        }
        if (winningWay == "DiagonalLeftUp"){
            MatchPlacementToButton(row,column).setBackgroundColor(c);
            MatchPlacementToButton(row-1,column-1).setBackgroundColor(c);
            MatchPlacementToButton(row-2,column-2).setBackgroundColor(c);
            MatchPlacementToButton(row-3,column-3).setBackgroundColor(c);
        }
    }//After a winner is found, marks in green the winning sequence
    public Button MatchPlacementToButton(int row, int column){
        Button winner=null;
        if (row==0) {
            if (column==0)
                winner = (Button)findViewById(R.id.zeroZero);
            else if (column==1)
                winner = (Button)findViewById(R.id.oneZero);
            else if (column==2)
                winner = (Button)findViewById(R.id.twoZero);
            else if (column==3)
                winner = (Button)findViewById(R.id.threeZero);
            else if (column==4)
                winner = (Button)findViewById(R.id.fourZero);
            else if (column==5)
                winner = (Button)findViewById(R.id.fiveZero);
        }
        else if (row==1) {
            if (column==0)
                winner = (Button)findViewById(R.id.zeroOne);
            else if (column==1)
                winner = (Button)findViewById(R.id.oneOne);
            else if (column==2)
                winner = (Button)findViewById(R.id.twoOne);
            else if (column==3)
                winner = (Button)findViewById(R.id.threeOne);
            else if (column==4)
                winner = (Button)findViewById(R.id.fourOne);
            else if (column==5)
                winner = (Button) findViewById(R.id.fiveOne);
        }
        else if (row==2) {
            if (column==0)
                winner = (Button)findViewById(R.id.zeroTwo);
            else if (column==1)
                winner = (Button)findViewById(R.id.oneTwo);
            else if (column==2)
                winner = (Button) findViewById(R.id.twoTwo);
            else if (column==3)
                winner = (Button) findViewById(R.id.threeTwo);
            else if (column==4)
                winner = (Button)findViewById(R.id.fourTwo);
            else if (column==5)
                winner = (Button)findViewById(R.id.fiveTwo);
        }
        else if (row==3) {
            if (column==0)
                winner = (Button)findViewById(R.id.zeroThree);
            else if (column==1)
                winner = (Button) findViewById(R.id.oneThree);
            else if (column==2)
                winner = (Button) findViewById(R.id.twoThree);
            else if (column==3)
                winner = (Button)findViewById(R.id.threeThree);
            else if (column==4)
                winner = (Button)findViewById(R.id.fourThree);
            else if (column==5)
                winner = (Button) findViewById(R.id.fiveThree);
        }
        else if (row==4) {
            if (column==0)
                winner = (Button)findViewById(R.id.zeroFour);
            else if (column==1)
                winner = (Button)findViewById(R.id.oneFour);
            else if (column==2)
                winner = (Button)findViewById(R.id.twoFour);
            else if (column==3)
                winner = (Button)findViewById(R.id.threeFour);
            else if (column==4)
                winner = (Button)findViewById(R.id.fourFour);
            else if (column==5)
                winner = (Button) findViewById(R.id.fiveFour);
        }
        else if (row==5) {
            if (column==0)
                winner = (Button)findViewById(R.id.zeroFive);
            else if (column==1)
                winner = (Button)findViewById(R.id.oneFive);
            else if (column==2)
                winner = (Button)findViewById(R.id.twoFive);
            else if (column==3)
                winner = (Button)findViewById(R.id.threeFive);
            else if (column==4)
                winner = (Button)findViewById(R.id.fourFive);
            else if (column==5)
                winner = (Button)findViewById(R.id.fiveFive);
        }
        else if (row==6) {
            if (column==0) {
                winner = (Button)findViewById(R.id.zeroSix);
            } else if (column==1) {
                winner = (Button)findViewById(R.id.oneSix);
            }
            else if (column==2) {
                winner = (Button)findViewById(R.id.twoSix);
            }
            else if (column==3) {
                winner = (Button)findViewById(R.id.threeSix);
            }
            else if (column==4){
                winner =(Button)findViewById(R.id.fourSix);}
            else if (column==5){
                winner = (Button)findViewById(R.id.fiveSix);}
        }
        return winner;
    }//Matches between a placement with row and column to a button on the board
    public void BuildGameBoard(){
        for (int i=0; i<gameBoard.length;i++){
            for (int j=0; j<gameBoard[i].length;j++)
                gameBoard[i][j] = 0;
        }
    }//Builds/resets the gameBoard array
    public String FindByIntId(int id){
        if (id == R.id.zeroZero){
            return "zeroZero";}
        else if (id == R.id.zeroOne){
            return "zeroOne";}
        else if (id == R.id.zeroTwo){
            return "zeroTwo";}
        if (id == R.id.zeroThree){
            return "zeroThree";}
        if (id == R.id.zeroFour){
            return "zeroFour";}
        if (id == R.id.zeroFive){
            return "zeroFive";}
        if (id == R.id.zeroSix){
            return "zeroSix";}
        else if (id == R.id.oneZero){
            return "oneZero";}
        else if (id == R.id.oneOne){
            return "oneOne";}
        else if (id == R.id.oneTwo){
            return "oneTwo";}
        if (id == R.id.oneThree){
            return "oneThree";}
        if (id == R.id.oneFour){
            return "oneFour";}
        if (id == R.id.oneFive){
            return "oneFive";}
        if (id == R.id.oneSix){
            return "oneSix";}
        else if (id == R.id.twoZero){
            return "twoZero";}
        else if (id == R.id.twoOne){
            return "twoOne";}
        else if (id == R.id.twoTwo){
            return "twoTwo";}
        if (id == R.id.twoThree){
            return "twoThree";}
        if (id == R.id.twoFour){
            return "twoFour";}
        if (id == R.id.twoFive){
            return "twoFive";}
        if (id == R.id.twoSix){
            return "twoSix";}
        if (id == R.id.threeZero){
            return "threeZero";}
        else if (id == R.id.threeOne){
            return "threeOne";}
        else if (id == R.id.threeTwo){
            return "threeTwo";}
        if (id == R.id.threeThree){
            return "threeThree";}
        if (id == R.id.threeFour){
            return "threeFour";}
        if (id == R.id.threeFive){
            return "threeFive";}
        if (id == R.id.threeSix){
            return "threeSix";}
        if (id == R.id.fourZero){
            return "fourZero";}
        else if (id == R.id.fourOne){
            return "fourOne";}
        else if (id == R.id.fourTwo){
            return "fourTwo";}
        if (id == R.id.fourThree){
            return "fourThree";}
        if (id == R.id.fourFour){
            return "fourFour";}
        if (id == R.id.fourFive){
            return "fourFive";}
        if (id == R.id.fourSix){
            return "fourSix";}
        if (id == R.id.fiveZero){
            return "fiveZero";}
        else if (id == R.id.fiveOne){
            return "fiveOne";}
        else if (id == R.id.fiveTwo){
            return "fiveTwo";}
        if (id == R.id.fiveThree){
            return "fiveThree";}
        if (id == R.id.fiveFour){
            return "fiveFour";}
        if (id == R.id.fiveFive){
            return "fiveFive";}
        if (id == R.id.fiveSix){
            return "fiveSix";}
        return "";
    }//Matches between id in integer and id in String of view object
    public boolean IsRowFull(String id){
        if (id == "zeroZero"|| id == "oneZero"||id == "twoZero"||id == "threeZero"||id == "fourZero"|| id == "fiveZero"){
            if (gameBoard[0][0] != 0)
                return true;
        }
        else if (id == "zeroOne"|| id == "oneOne"||id == "twoOne"||id == "threeOne"||id == "fourOne"|| id == "fiveOne"){
            if (gameBoard[0][1] != 0)
                return true;
        }
        else if (id == "zeroTwo"|| id == "oneTwo"||id == "twoTwo"||id == "threeTwo"||id == "fourTwo"|| id == "fiveTwo"){
            if (gameBoard[0][2] != 0)
                return true;
        }
        else if (id == "zeroThree"|| id == "oneThree"||id == "twoThree"||id == "threeThree"||id == "fourThree"|| id == "fiveThree"){
            if (gameBoard[0][3] != 0)
                return true;
        }
        else if (id == "zeroFour"|| id == "oneFour"||id == "twoFour"||id == "threeFour"||id == "fourFour"|| id == "fiveFour"){
            if (gameBoard[0][4] != 0)
                return true;
        }
        else if (id == "zeroFive"|| id == "oneFive"||id == "twoFive"||id == "threeFive"||id == "fourFive"|| id == "fiveFive"){
            if (gameBoard[0][5] != 0)
                return true;
        }
        else if (id == "zeroSix"|| id == "oneSix"||id == "twoSix"||id == "threeSix"||id == "fourSix"|| id == "fiveSix"){
            if (gameBoard[0][6] != 0)
                return true;
        }
        return false;
    }//Checks if the selected row is full
    public void Mark(boolean color) {
        if (id == "zeroZero" || id == "oneZero" || id == "twoZero" || id == "threeZero" || id == "fourZero" || id == "fiveZero") {
            if (gameBoard[0][0] == 0) {
                MiniMark(0,color);
            }

        } else if (id == "zeroOne" || id == "oneOne" || id == "twoOne" || id == "threeOne" || id == "fourOne" || id == "fiveOne") {
            if (gameBoard[0][1] == 0) {
                MiniMark(1,color);
            }

        } else if (id == "zeroTwo" || id == "oneTwo" || id == "twoTwo" || id == "threeTwo" || id == "fourTwo" || id == "fiveTwo") {
            if (gameBoard[0][2] == 0) {
                MiniMark(2,color);
            }

        } else if (id == "zeroThree" || id == "oneThree" || id == "twoThree" || id == "threeThree" || id == "fourThree" || id == "fiveThree") {
            if (gameBoard[0][3] == 0) {
                MiniMark(3,color);
            }

        } else if (id == "zeroFour" || id == "oneFour" || id == "twoFour" || id == "threeFour" || id == "fourFour" || id == "fiveFour") {
            if (gameBoard[0][4] == 0) {
                MiniMark(4,color);
            }

        } else if (id == "zeroFive" || id == "oneFive" || id == "twoFive" || id == "threeFive" || id == "fourFive" || id == "fiveFive") {
            if (gameBoard[0][5] == 0) {
                MiniMark(5,color);
            }

        } else if (id == "zeroSix" || id == "oneSix" || id == "twoSix" || id == "threeSix" || id == "fourSix" || id == "fiveSix") {
            if (gameBoard[0][6] == 0) {
                MiniMark(6,color);
            }

        }
    }//Marks on the board and in the gameBoard the chosen button
    public void MiniMark(int row, boolean color) {
        int lastChecked = CheckLastCheckedIndex(row);
        gameBoard[lastChecked][row] = player;
        if (color)
            c = Color.RED;
        else
            c = Color.YELLOW;
        if (row==0) {
            if (lastChecked==0)
                findViewById(R.id.zeroZero).setBackgroundColor(c);
            else if (lastChecked==1)
                findViewById(R.id.oneZero).setBackgroundColor(c);
            else if (lastChecked==2)
                findViewById(R.id.twoZero).setBackgroundColor(c);
            else if (lastChecked==3)
                findViewById(R.id.threeZero).setBackgroundColor(c);
            else if (lastChecked==4)
                findViewById(R.id.fourZero).setBackgroundColor(c);
            else if (lastChecked==5)
                findViewById(R.id.fiveZero).setBackgroundColor(c);
        }
        else if (row==1) {
            if (lastChecked==0)
                findViewById(R.id.zeroOne).setBackgroundColor(c);
            else if (lastChecked==1)
                findViewById(R.id.oneOne).setBackgroundColor(c);
            else if (lastChecked==2)
                findViewById(R.id.twoOne).setBackgroundColor(c);
            else if (lastChecked==3)
                findViewById(R.id.threeOne).setBackgroundColor(c);
            else if (lastChecked==4)
                findViewById(R.id.fourOne).setBackgroundColor(c);
            else if (lastChecked==5)
                findViewById(R.id.fiveOne).setBackgroundColor(c);
        }
        else if (row==2) {
            if (lastChecked==0)
                findViewById(R.id.zeroTwo).setBackgroundColor(c);
            else if (lastChecked==1)
                findViewById(R.id.oneTwo).setBackgroundColor(c);
            else if (lastChecked==2)
                findViewById(R.id.twoTwo).setBackgroundColor(c);
            else if (lastChecked==3)
                findViewById(R.id.threeTwo).setBackgroundColor(c);
            else if (lastChecked==4)
                findViewById(R.id.fourTwo).setBackgroundColor(c);
            else if (lastChecked==5)
                findViewById(R.id.fiveTwo).setBackgroundColor(c);
        }
        else if (row==3) {
            if (lastChecked==0)
                findViewById(R.id.zeroThree).setBackgroundColor(c);
            else if (lastChecked==1)
                findViewById(R.id.oneThree).setBackgroundColor(c);
            else if (lastChecked==2)
                findViewById(R.id.twoThree).setBackgroundColor(c);
            else if (lastChecked==3)
                findViewById(R.id.threeThree).setBackgroundColor(c);
            else if (lastChecked==4)
                findViewById(R.id.fourThree).setBackgroundColor(c);
            else if (lastChecked==5)
                findViewById(R.id.fiveThree).setBackgroundColor(c);
        }
        else if (row==4) {
            if (lastChecked==0)
                findViewById(R.id.zeroFour).setBackgroundColor(c);
            else if (lastChecked==1)
                findViewById(R.id.oneFour).setBackgroundColor(c);
            else if (lastChecked==2)
                findViewById(R.id.twoFour).setBackgroundColor(c);
            else if (lastChecked==3)
                findViewById(R.id.threeFour).setBackgroundColor(c);
            else if (lastChecked==4)
                findViewById(R.id.fourFour).setBackgroundColor(c);
            else if (lastChecked==5)
                findViewById(R.id.fiveFour).setBackgroundColor(c);
        }
        else if (row==5) {
            if (lastChecked==0)
                findViewById(R.id.zeroFive).setBackgroundColor(c);
            else if (lastChecked==1)
                findViewById(R.id.oneFive).setBackgroundColor(c);
            else if (lastChecked==2)
                findViewById(R.id.twoFive).setBackgroundColor(c);
            else if (lastChecked==3)
                findViewById(R.id.threeFive).setBackgroundColor(c);
            else if (lastChecked==4)
                findViewById(R.id.fourFive).setBackgroundColor(c);
            else if (lastChecked==5)
                findViewById(R.id.fiveFive).setBackgroundColor(c);
        }
        else if (row==6) {
            if (lastChecked==0)
                findViewById(R.id.zeroSix).setBackgroundColor(c);
            else if (lastChecked==1)
                findViewById(R.id.oneSix).setBackgroundColor(c);
            else if (lastChecked==2)
                findViewById(R.id.twoSix).setBackgroundColor(c);
            else if (lastChecked==3)
                findViewById(R.id.threeSix).setBackgroundColor(c);
            else if (lastChecked==4)
                findViewById(R.id.fourSix).setBackgroundColor(c);
            else if (lastChecked==5)
                findViewById(R.id.fiveSix).setBackgroundColor(c);
        }
    }//Used in "Mark()" to find the last button checked from the row of the selected button and mark it on the game board
    public int CheckLastCheckedIndex(int i){
        for (int j=5; j>0;j--){
            if (gameBoard[j][i]==0)
                return j;
        }
        return 0;
    }//Returns the index of the last checked button from a certain row
    public boolean CheckIfWon() {
        //Horizontal+Vertical
        for (int i = 0; i < gameBoard.length; i++){
            //Horizontal
            if (gameBoard[i][0] == player && gameBoard[i][1] == player && gameBoard[i][2] == player && gameBoard[i][3] == player) {
                winningRow=0;
                winningColumn=i;
                winningWay = "Horizontal";
                return true;
            }
            if( gameBoard[i][4] == player && gameBoard[i][1] == player && gameBoard[i][2] == player && gameBoard[i][3] == player){
                winningRow=1;
                winningColumn=i;
                winningWay = "Horizontal";
                return true;
            }
            if( gameBoard[i][4] == player && gameBoard[i][5] == player && gameBoard[i][2] == player && gameBoard[i][3] == player) {
                winningRow=2;
                winningColumn=i;
                winningWay = "Horizontal";
                return true;
            }
            //Vertical
            if (gameBoard[0][i] == player && gameBoard[1][i] == player && gameBoard[2][i] == player && gameBoard[3][i] == player) {
                winningRow=i;
                winningColumn=2;
                winningWay = "Vertical";
                return true;
            }
            if ( gameBoard[4][i] == player && gameBoard[1][i] == player && gameBoard[2][i] == player && gameBoard[3][i] == player) {
                winningRow=i;
                winningColumn=1;
                winningWay = "Vertical";
                return true;
            }
            if(gameBoard[4][i] == player && gameBoard[5][i] == player && gameBoard[2][i] == player && gameBoard[3][i] == player) {
                winningRow=i;
                winningColumn=2;
                winningWay = "Vertical";
                return true;
            }
        }

        //Diagonal
        for (int column = 0; column < gameBoard.length; column++){//0-5
            for(int row = 0; row < gameBoard[column].length; row++){//0-6
                if (row<3){
                    if (column<3){
                        if (gameBoard[column][row] == player && gameBoard[column+1][row+1] == player && gameBoard[column+2][row+2] == player&& gameBoard[column+3][row+3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalRightDown";
                            return true;
                        }
                    }
                    else if (column>=3){
                        if (gameBoard[column][row] == player && gameBoard[column-1][row+1] == player && gameBoard[column-2][row+2] == player&& gameBoard[column-3][row+3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalRightUp";
                            return true;
                        }
                    }
                }
                else if (row==3){
                    if (column<3){
                        if (gameBoard[column][row] == player && gameBoard[column+1][row+1] == player && gameBoard[column+2][row+2] == player&& gameBoard[column+3][row+3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalRightDown";
                            return true;
                        }
                        if (gameBoard[column][row] == player && gameBoard[column+1][row-1] == player && gameBoard[column+2][row-2] == player&& gameBoard[column+3][row-3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalLeftDown";
                            return true;
                        }
                    }
                    else if (column>=3){
                        if (gameBoard[column][row] == player && gameBoard[column-1][row-1] == player && gameBoard[column-2][row-2] == player&& gameBoard[column-3][row-3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalLeftUp";
                            return true;
                        }
                        if (gameBoard[column][row] == player && gameBoard[column-1][row+1] == player && gameBoard[column-2][row+2] == player&& gameBoard[column-3][row+3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalRightUp";
                            return true;
                        }
                    }
                }
                else if(row>3){
                    if (column<3){
                        if (gameBoard[column][row] == player && gameBoard[column+1][row-1] == player && gameBoard[column+2][row-2] == player&& gameBoard[column+3][row-3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalLeftDown";
                            return true;
                        }
                    }
                    else if (column>=3){
                        if (gameBoard[column][row] == player && gameBoard[column-1][row-1] == player && gameBoard[column-2][row-2] == player&& gameBoard[column-3][row-3] == player){
                            winningRow=row;
                            winningColumn=column;
                            winningWay = "DiagonalLeftUp";
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }//Checks if a player won
    public boolean IsBoardFull(){
        boolean isFull=false;
        if (IsRowFull("zeroZero")&&IsRowFull("zeroOne")&&IsRowFull("zeroTwo")&&IsRowFull("zeroThree")&&IsRowFull("zeroFour")&&IsRowFull("zeroFive"))
            isFull = true;
        return isFull;
    }//Checks if the board is full
    public void Restart(){
        BuildGameBoard();
        playerSwitch = true;
        player =0;
        id = "";
        winningColumn = -1;
        winningRow = -1;
        winningWay="";
        c = -1;
        chosen = null;
        active = true;
        ResetBoard();
    }//Restarts the game
    public void ResetBoard(){
        for (int i=0; i<gameBoard.length;i++){
            for (int j=0; j<gameBoard[i].length;j++)
                MatchPlacementToButton(j,i).setBackgroundColor(Color.WHITE);
        }
    }//Reset the buttons on the game Board
    public void EndGame(){
        Toast.makeText(MainActivity.this,"App will be closed soon. Press 'Restart' if you would like to play again", Toast.LENGTH_LONG).show();
        cdt = new CountDownTimer(10000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                finish();
                System.exit(0);
            }
        }.start();
    }//Creates a delay before the application will be closed
}