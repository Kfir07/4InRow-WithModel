package com.example.homework9_4inarow;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Model model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        model = new Model(this);

        model.BuildGameBoard();
        model.playerSwitch = true;
        model.restart = findViewById(R.id.restart);
        model.restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                model.cdt.cancel();
                model.Restart();
            }
        });
    }
    public void onClick (View view) {
        if (model.active) {
            model.chosen = (Button) view;
            model.id = model.FindByIntId(view.getId());
            if (!model.IsRowFull(model.id)) {
                if (model.playerSwitch) {
                    model.player = 1;
                    model.Mark(model.playerSwitch);
                } else {
                    model.player = 2;
                    model.Mark(model.playerSwitch);
                }
                if (model.CheckIfWon()) {
                    model.MarkWinner(model.winningRow, model.winningColumn, model.winningWay);
                    Toast.makeText(MainActivity.this, "Player " + model.player + " Won", Toast.LENGTH_LONG).show();
                    model.active = false;
                    model.EndGame();
                } else if (model.IsBoardFull()) {
                    Toast.makeText(MainActivity.this, "Its A Tie!!", Toast.LENGTH_LONG).show();
                    model.active = false;
                    model.EndGame();
                } else {
                    if (model.playerSwitch)
                        model.playerSwitch = false;
                    else
                        model.playerSwitch = true;
                }
            } else {
                Toast.makeText(MainActivity.this, "Row is full. Please select a different row", Toast.LENGTH_LONG).show();
            }
        }
    }//On click listener to all buttons on the board

}